
#include "examples_date.cc"
#include "examples_dated.cc"
#include "examples_dated_obs.cc"
#include "examples_security_price_history.cc"
#include "examples_stock_price_history.cc"




int main(){
    examples_date();
    examples_dated();
    examples_dated_obs();
    examples_security_price_history();
    examples_stock_price_history();
};
